<template>
	<div>NoticeView</div>
</template>

<script setup></script>

<style scoped></style>
