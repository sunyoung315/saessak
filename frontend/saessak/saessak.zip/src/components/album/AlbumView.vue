<template>
	<div class="container p-6">
		<span class="text-4xl m-5 font-extrabold">앨범</span>
		<RouterView />
	</div>
</template>

<script setup></script>

<style scoped></style>
