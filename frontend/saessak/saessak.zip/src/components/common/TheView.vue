<template>
	<div class="w-3/4">
		<RouterView></RouterView>
	</div>
</template>

<script setup></script>

<style scoped></style>
