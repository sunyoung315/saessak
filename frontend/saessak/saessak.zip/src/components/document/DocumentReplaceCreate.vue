<template>
	<div>
		<h2>Replace Create</h2>
	</div>
</template>

<script setup></script>

<style scoped></style>
