<template>
	<div>
		<div class="container p-6 flex items-center">
			<div>
				<span class="text-4xl mt-10 ml-14 mb-3 mr-5 font-extrabold inline-block"
					>동의서</span
				>
			</div>
		</div>
		<router-view />
	</div>
</template>

<script setup></script>

<style scoped></style>
