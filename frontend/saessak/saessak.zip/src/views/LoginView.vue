<template>
	<div>
		<h1>login Page</h1>
	</div>
</template>

<script setup></script>

<style scoped></style>
