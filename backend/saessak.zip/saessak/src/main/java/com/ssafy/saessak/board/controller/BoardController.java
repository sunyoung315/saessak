package com.ssafy.saessak.board.controller;


import com.ssafy.saessak.board.domain.Board;
import com.ssafy.saessak.board.dto.*;
import com.ssafy.saessak.board.service.BoardService;
import com.ssafy.saessak.result.ResultCode;
import com.ssafy.saessak.result.ResultResponse;
import io.swagger.v3.oas.annotations.Operation;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController()
@RequestMapping("/api/board")
@Slf4j
public class BoardController {


    private final BoardService boardService;

//    @GetMapping("/health")
//    public ResponseEntity<ResultResponse> getHealth(){
//        return ResponseEntity.ok(ResultResponse.of(ResultCode.SUCCESS,"success"));
//    }

    // 아이 알림장 전체 조회
    @GetMapping("/{kidId}")
    public ResponseEntity<ResultResponse> getBoardList(@PathVariable(name = "kidId") Long kidId){
        List<BoardResponseDto> result = boardService.findByKid(kidId);
        return ResponseEntity.ok(ResultResponse.of(ResultCode.SUCCESS, result));
    }
    // 알림장 등록
    @PostMapping("")
    public ResponseEntity<ResultResponse> insertBoard(@RequestBody BoardRequestDto boardRequestDto){
        Board board = boardService.saveBoard(boardRequestDto);
        return ResponseEntity.ok(ResultResponse.of(ResultCode.SUCCESS, board.getBoardId()));
    }
    // 알림장 조회
    @GetMapping("/{boardId}")
    public ResponseEntity<ResultResponse> readBoard(@PathVariable(name = "boardId") Long boardId){
        BoardDetailDto boardDetailDto = boardService.readBoard(boardId);
        return ResponseEntity.ok(ResultResponse.of(ResultCode.SUCCESS, boardDetailDto));
    }
    // 알림장 삭제
    @DeleteMapping("/{boardId}")
    public ResponseEntity<ResultResponse> deleteBoard(@PathVariable(name = "boardId") Long boardId){
        Long result = boardService.deleteBoard(boardId);
        return ResponseEntity.ok(ResultResponse.of(ResultCode.SUCCESS, result));
    }
    // 알림장 수정

    // 달력을 통해 알림장 조회
    @PostMapping("/day/{kidId}")
    public ResponseEntity<ResultResponse> getBoardByDate(@PathVariable (name = "kidId") Long kidId,
                                                         @RequestBody DateRequestDto dateRequestDto){
        log.debug("받은 날짜 데이터 : {} " , dateRequestDto.getBoardDate());

        BoardDetailDto baordBoardDetailDto =  boardService.findByKidAndDate(kidId, dateRequestDto.getBoardDate());

        return ResponseEntity.ok(ResultResponse.of(ResultCode.SUCCESS, baordBoardDetailDto));
    }
    // 아이의 가장 최근 알림장 조회
    @GetMapping("/current/{kidId}")
    public ResponseEntity<ResultResponse> getKidCurrentBoard(@PathVariable(name = "kidId") Long kidId){
        BoardDetailDto boardDetailDto = boardService.getKidCurrentBoard(kidId);
        return ResponseEntity.ok(ResultResponse.of(ResultCode.SUCCESS, boardDetailDto));
    }
    @PostMapping("/physical/{kidId}")
    public ResponseEntity<ResultResponse> getPhysicalList(@PathVariable (name= "kidId") Long kidId,
                                                          @RequestBody DateBetweenRequestDto dateBetweenRequestDto){
        log.debug("받은 날짜 데이터 : {} ~ {} ", dateBetweenRequestDto.getStartDate(), dateBetweenRequestDto.getEndDate());
        List<PhysicalResponseDto> result = boardService.getPhysicalList(kidId,
                dateBetweenRequestDto.getStartDate(), dateBetweenRequestDto.getEndDate());
        return ResponseEntity.ok(ResultResponse.of(ResultCode.SUCCESS, result));
    }

    @PostMapping("/summary/{kidId}")
    public ResponseEntity<ResultResponse> getContentList(@PathVariable(name = "kidId") Long kidId,
                                                         @RequestBody DateBetweenRequestDto dateBetweenRequestDto){

        List<ContentResponseDto> result = boardService.getContentList(kidId,
                dateBetweenRequestDto.getStartDate(), dateBetweenRequestDto.getEndDate());


        return ResponseEntity.ok(ResultResponse.of(ResultCode.SUCCESS, result));
    }
}
